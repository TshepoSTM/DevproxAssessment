<?php
//Include database connection
include('dbconnection.php');

$filename = $_FILES['file']['name'];
$tempfile = $_FILES['file']['tmp_name'];

$uploaddir = './output/';
$uploadedfile = $uploaddir.$filename;

$myfile = fopen('output/'.$filename, "r") or die("Unable to open file!");

while (($data = fgetcsv($myfile,1000000, ";")) !== FALSE)
{
	// Assign the data from file   
	$array_values[] = $data; 
	
	/*for($i=0;$i<count($data);$i++)
	{
		print($data[$i]);
	}*/
}
fclose($myfile);

//creating heading
$id = $array_values[0][0];
$Name = $array_values[0][1];
$Surname = $array_values[0][2];
$Initials = $array_values[0][3];
$Age = $array_values[0][4];
$DateOfBirth = $array_values[0][5];



for($n=1;$n<count($array_values);$n++)
{	
	//Assingning data values
	$names_data[] = $array_values[$n][1];
	$surnames_data[] = $array_values[$n][2];
	$initials_data[] = $array_values[$n][3];
	$age_data[] = $array_values[$n][4];
	$dob_data[] = $array_values[$n][5];
	
	for($m=0;$m<$n;$m++)
	{	
		//echo json_encode($array_values[$n][$m]);
	}
	
}



// Create database
$createdb_sql = "CREATE DATABASE myDB";
if(mysqli_query($conn, $createdb_sql)) {
  //echo "Database created successfully";
  
	//query to create table
	$sql = "CREATE OR REPLACE TABLE myDB.csv_import (
			id INT(11) AUTO_INCREMENT PRIMARY KEY,
			Name VARCHAR(30) NOT NULL,
			Surname VARCHAR(30) NOT NULL,
			Initials VARCHAR(50) NOT NULL,
			Age INT(11) NOT NULL,
			DateOfBirth VARCHAR(50) NOT NULL
		)";

	if (mysqli_query($conn, $sql)) {
		
		$insert_query;
		$last_id;
		for($i=0;$i<count($names_data);$i++)
		{
			//query to insert records
			$insert_query[$i] = "INSERT INTO myDB.csv_import (Name, Surname, Initials,Age,DateOfBirth)
					VALUES ('".$names_data[$i]."', '".$surnames_data[$i]."', '".$initials_data[$i]."','".$age_data[$i]."','".$dob_data[$i]."')";
					
			//echo json_encode($insert_query); exit;
			if (mysqli_query($conn, $insert_query[$i])) {
					
					$last_id = mysqli_insert_id($conn);
					//echo "New record created successfully".$last_id;
				  
			} else {
				echo "Error: " . $insert_query[$i] . "<br>" . mysqli_error($conn);
			}
		}
		
		echo $last_id.' records imported. <a href="index.php">click here to go back</a>';
		
	  
	} else {
		
	  echo "Error in creating table: " . mysqli_error($conn);
	  
	}

} else {
  echo "Error in creating database: " . mysqli_error($conn).' <a href="index.php">click here to go back</a>';
}

mysqli_close($conn);

?>