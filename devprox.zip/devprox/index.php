<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Index</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<meta name="author" content="">
	</head>
	<body>
		<form class="form-horizontal" id="frmRecord" action="exercise1.php" method="post">
			<div class="control-group">
				<label class="control-label" for="inputLnam">Enter number <sup></sup></label>
				<div class="controls">
				  <input type="text" id="inputNumber" name="inputNumber" placeholder="Number of Records" required>
				  <input class="btn btn-large btn-success" type="submit" id="btnSubmit" value="Submit" />
				</div>
			 </div>
			 <br/>
		</form>
		<form class="form-horizontal" id="frmFile" method="post" action="upload.php" enctype="multipart/form-data">
			<div class="control-group">
				<label class="control-label" for="inputLnam"><sup></sup></label>
				<div class="controls">
				  <input type="file" id="file" name="file" required> 
				</div>
			</div>
			<br/>
			<input class="btn btn-large btn-success" type="submit" id="btnSubmitFile" value="Submit" />
			 <br/>
		</form>
	</body>
</body>

<style>
body {
 
  width:250px;
}
form {
	margin:5px
	
}
</style>
</html>