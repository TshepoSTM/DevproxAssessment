<?php

$counter = $_POST['inputNumber'];

$names = array('Tshepo','Sello','Tyron James','Franse','ezra','thabo','lebo','michele','hunadi','nthabi',
				'bontle','cheyi','karabo','wendy','mercy','percy','lucy','thapelo','mpho','greg');
$surnames = array('mathatho','maake','hughs','berger','kgatle','molaudzi','matosa','rangs','kwetse','mogatla',
				'smith','maleka','malete','Williams','mercy','Taylor','Jones','thapelo','mpho','Smith');
			
$initials =  $names;

//echo json_encode($initials);exit;
/*$initials_array;
foreach($initials as $initial)
{
	$initials_array[] = $initial[0];
}

/*$initial = implode(' ', array_map(function ($name) { 
    preg_match_all('/\b\w/', $name, $matches);
    return implode('', $matches[0]);
}, $names)); */

function getAge($date) 
{ 
	$now = date('Ymd');
	$_date = date('Ymd', strtotime($date));
	$birth_year = substr($now,0,4);
	$year = substr($_date,0,4);
	$age = substr($birth_year.' '.$_date.','.(intval($birth_year)-intval($year)),-2,2);
	return $age ;
}

function randomNames($names,$surnames,$counter) {
	
	$fullNames = array();
	$initials_array;
	for($i = 0; $i < $counter;$i++) {
		
		//$c = $i;
		$newNames = $names[rand(0, count($names)-1)];
		
		$newInitials = strtoupper($newNames[0]);
		$newSurname = $surnames[rand(0, count($names)-1)];
		
		$cur_date = time();
		
		$newDates= mt_rand(0,$cur_date);
		$bithdates = date('d/m/Y',$newDates);
		
		//Function call to calculate age
		$age = getAge($bithdates);
		
		
		$fullNames[] = array('id'=>($i+1),'Names'=>$newNames,'Surname'=>$newSurname,'Initials'=>$newInitials,'Age'=>$age,'DateOfbirth'=>$bithdates);
		//$fullNames[] = array('Age'=>$age,'DateOfbirth'=>$bithdates);//." ".$newSurname;
	}
	
	return $fullNames;
}

//Function that write to file
function write_to_file($data)
{
	$myfile = fopen("output/output.csv", "w") or die("Unable to open file!");
	
	$columns = array("Id","Name","Surname","Initials","Age","DateOfBirth");
	
	fputcsv($myfile, $columns,";");
	
	foreach($data as $row)
	{
		//$val = explode(",", $row);
		fputcsv($myfile, $row,";");
	}
	
	fclose($myfile);
}


$data = randomNames($names,$surnames,$counter);

write_to_file($data);

echo ("File generated to output folder. <a href='index.php'>click here to import file to database</a>");



/*
foreach(randomNames($names,$surnames,$counter) as $names)
{
	echo json_encode($names['Initials']);
}*/

?>