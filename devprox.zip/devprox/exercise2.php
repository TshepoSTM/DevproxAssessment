<?php

/*include('exercise1.php');

//Function that write to file
function write_to_file($data)
{
	$myfile = fopen("output/output.csv", "w") or die("Unable to open file!");
	
	$columns = array("Id","Name","Surname","Initials","Age","DateOfBirth");
	
	fputcsv($myfile, $columns,";");
	
	foreach($data as $row)
	{
		//$val = explode(",", $row);
		//echo json_encode($row);
		fputcsv($myfile, $row,";");
	}
	
	fclose($myfile);
}

write_to_file($data);*/
?>